"""Recover cleanly from an unclean shutdown.

Two problems this solves for an appliance that restarts unattended:

1. Jobs persisted as ``running`` by a previous process are replayed to every
   new browser as "running" forever, permanently disabling the report button.
2. Child ``nmap``/``arp-scan`` processes need a termination signal when the
   application shuts down normally or receives SIGTERM/SIGINT.

``reconcile_interrupted_jobs`` marks stale jobs interrupted at startup.
``install_process_reaper`` terminates tracked children on SIGTERM/SIGINT and at
normal interpreter exit. SIGKILL cannot run these handlers; forced-crash child
cleanup requires external process supervision and is not guaranteed here.
"""

from __future__ import annotations

import atexit
import logging
import uuid
import os
import signal
import sys
import threading
from datetime import datetime, timezone

logger = logging.getLogger(__name__)

STALE_JOB_STATUSES = ("running", "cancelling")


def reconcile_interrupted_jobs(*, runtime_store, logger=logger, status=None) -> list[str]:
    """Mark jobs left running by a previous process as interrupted.

    Returns the job ids that were reconciled.
    """
    if status is not None:
        status.update({"ok": True, "failed_jobs": 0, "listing_error": None})
    if runtime_store is None or not hasattr(runtime_store, "list_jobs"):
        return []

    interrupted: list[str] = []
    failed_jobs = 0
    before: tuple[str, str] | None = None
    while True:
        try:
            stale_jobs = runtime_store.list_jobs(
                statuses=STALE_JOB_STATUSES, limit=200, before=before
            )
        except Exception as exc:
            logger.error("Could not list persisted jobs for startup recovery: %s", exc)
            if status is not None:
                status["ok"] = False
                status["listing_error"] = "Could not list persisted jobs"
            break
        if not stale_jobs:
            break
        last_job = stale_jobs[-1]
        next_before = (last_job.get("updated_at"), last_job.get("job_id"))
        if not all(next_before) or next_before == before:
            logger.error("Could not advance startup recovery cursor past %s", before)
            if status is not None:
                status["ok"] = False
                status["listing_error"] = "Recovery cursor could not advance"
            break
        for job in stale_jobs:
            job_id = job.get("job_id")
            if not job_id:
                continue
            payload = dict(job.get("payload") or {})
            finished_at = datetime.now(timezone.utc).isoformat()
            payload.update(
                {
                    "interrupted": True,
                    "recovery_note": "Process restarted while this job was running",
                    "finished_at": finished_at,
                    "interrupted_at": finished_at,
                }
            )
            try:
                runtime_store.upsert_job(
                    job_id=job_id,
                    owner_sid=job.get("owner_sid"),
                    job_type=job.get("job_type") or "report",
                    status="interrupted",
                    payload=payload,
                )
                source_job_id = payload.get("source_job_id")
                source_job_type = payload.get("source_job_type")
                if source_job_id and source_job_type in {"scan", "report"} and hasattr(runtime_store, "append_job_event"):
                    try:
                        source_job_id = str(uuid.UUID(source_job_id))
                    except (ValueError, TypeError, AttributeError):
                        source_job_id = None
                    if source_job_id:
                        recovery_payload = {**payload, "status": "interrupted", "job_type": source_job_type}
                        source_event = {"client_event_id": str(uuid.uuid4()), "occurred_at": finished_at,
                                        "event_name": "job_status", "payload": recovery_payload,
                                        "source_job_id": source_job_id, "source_job_type": source_job_type}
                        runtime_store.append_job_event(job_id=job_id, owner_sid=job.get("owner_sid"), job_type=source_job_type,
                                                       event_name="job_status", payload=recovery_payload, source_event=source_event)
                interrupted.append(job_id)
            except Exception as exc:
                failed_jobs += 1
                if failed_jobs <= 10:
                    logger.error("Failed to mark job %s as interrupted: %s", job_id, exc)
                if status is not None:
                    status["ok"] = False
                    status["failed_jobs"] = failed_jobs
        before = next_before

    if failed_jobs > 10:
        logger.error(
            "Startup recovery suppressed %d additional per-job write errors",
            failed_jobs - 10,
        )
    if interrupted:
        sample = ", ".join(interrupted[:10])
        remaining = len(interrupted) - 10
        logger.warning(
            "Recovered %d job(s) left running by a previous process: %s%s",
            len(interrupted),
            sample,
            f" (+{remaining} more)" if remaining > 0 else "",
        )
    return interrupted


def _signal_handlers_are_safe() -> bool:
    """Signal handlers may only be installed on the main thread, and must not
    be installed while a test runner owns the process."""
    if threading.current_thread() is not threading.main_thread():
        return False
    if "pytest" in sys.modules or os.environ.get("PYTEST_CURRENT_TEST"):
        return False
    return True


def install_process_reaper(*, job_registry, logger=logger) -> bool:
    """Terminate tracked child processes on shutdown signals and at exit.

    Returns True when signal handlers were installed.
    """
    if job_registry is None or not hasattr(job_registry, "terminate_all"):
        return False

    # Normal interpreter shutdown only; SIGKILL and os._exit bypass atexit.
    atexit.register(job_registry.terminate_all)

    if not _signal_handlers_are_safe():
        return False

    shutting_down = False

    def _handle_shutdown(signum, _frame):
        nonlocal shutting_down
        if shutting_down:
            return
        shutting_down = True
        # A signal can interrupt an active logging stream flush. Avoid both
        # reentrant buffered writes and repeated shutdown signals here.
        def write_notice(message):
            try:
                os.write(2, message.encode("utf-8"))
            except OSError:
                pass
        write_notice(f"Received signal {signum}; terminating tracked scan processes before exit\n")
        try:
            job_registry.terminate_all()
        except Exception:
            write_notice("Failed to terminate scan processes during shutdown\n")
        raise SystemExit(128 + signum)

    installed = False
    for name in ("SIGTERM", "SIGINT"):
        signum = getattr(signal, name, None)
        if signum is None:
            continue
        try:
            signal.signal(signum, _handle_shutdown)
            installed = True
        except (ValueError, OSError):
            logger.debug("Could not install %s handler", name)
    return installed
