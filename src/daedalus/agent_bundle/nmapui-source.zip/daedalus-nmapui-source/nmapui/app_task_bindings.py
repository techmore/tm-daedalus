from nmapui.app_composition import (
    build_report_task_deps,
    build_saved_pdf_task_deps,
    build_scan_task_deps,
)
from nmapui.app_scan_runtime import (
    run_arp_scan as run_arp_scan_runtime,
    run_nmap_with_xml_output as run_nmap_with_xml_output_runtime,
    start_scan_task as start_scan_task_runtime,
)
from nmapui.report_runtime import (
    generate_pdf_from_saved_task as generate_pdf_from_saved_task_runtime,
    generate_report_task as generate_report_task_runtime,
)


def build_task_bindings(
    *,
    broadcaster,
    emit_to_client,
    get_client_state,
    ensure_job_not_cancelled,
    idle_state_manager,
    update_job_progress,
    socketio,
    run_cancellable_command,
    identify_gateway_firewall_targets,
    job_registry,
    emit_job_status,
    logger,
    settings_state,
    vulners_script,
    default_interface,
    which,
    stylesheet_pdf,
    validate_target,
    split_subnet_into_chunks,
    create_scan_folder,
    scans_dir,
    sanitize_customer_dir_name,
    merge_nmap_xml_files,
    convert_xml_to_html,
    convert_html_to_pdf,
    web_stylesheet,
    stylesheet,
    get_app_version,
    save_scan_metadata,
    network_key,
    current_customer,
    extract_scan_statistics,
    customer_fingerprinter,
    upload_report_artifacts_to_google_drive,
    runtime_store,
    find_latest_saved_scan_for_pdf,
    load_json_document,
    normalize_scan_metadata_document,
):
    original_convert_xml_to_html = convert_xml_to_html

    def convert_xml_to_html(*args, **kwargs):
        kwargs["include_topology_recommendations"] = (settings_state.get("reports") or {}).get("include_topology_recommendations", False) is True
        return original_convert_xml_to_html(*args, **kwargs)

    def run_arp_scan(target, interface=None, sid=None, emit_to_client_override=None):
        return run_arp_scan_runtime(
            target=target,
            interface=interface,
            sid=sid,
            get_default_interface_cached=lambda: default_interface,
            which=which,
            emit_to_client=emit_to_client_override or emit_to_client,
            socketio_emit=socketio.emit,
            socketio_sleep=socketio.sleep,
            run_cancellable_command=run_cancellable_command,
        )

    def run_nmap_with_xml_output(
        target,
        output_base,
        scan_type="comprehensive",
        sid=None,
        excluded_targets=None,
        scan_only_mode=False,
        skip_host_discovery=False,
        force_privileged_scan=False,
        timeout_seconds=None,
        emit_to_client_override=None,
    ):
        return run_nmap_with_xml_output_runtime(
            target=target,
            output_base=output_base,
            scan_type=scan_type,
            sid=sid,
            excluded_targets=excluded_targets,
            scan_only_mode=scan_only_mode,
            skip_host_discovery=skip_host_discovery,
            force_privileged_scan=force_privileged_scan,
            timeout_seconds=timeout_seconds,
            vulners_script=vulners_script,
            stylesheet_pdf=stylesheet_pdf,
            emit_to_client=emit_to_client_override or emit_to_client,
            socketio_emit=socketio.emit,
            socketio_sleep=socketio.sleep,
            run_cancellable_command=run_cancellable_command,
        )

    def start_scan_task(sid, target, skip_host_discovery_override=None):
        return start_scan_task_runtime(
            sid=sid,
            target=target,
            skip_host_discovery_override=skip_host_discovery_override,
            **build_scan_task_deps(
                broadcaster=broadcaster,
                emit_to_client=emit_to_client,
                get_client_state=get_client_state,
                ensure_job_not_cancelled=ensure_job_not_cancelled,
                idle_state_manager=idle_state_manager,
                update_job_progress=update_job_progress,
                socketio_sleep=socketio.sleep,
                run_cancellable_command=run_cancellable_command,
                run_arp_scan=run_arp_scan,
                identify_gateway_firewall_targets=lambda hosts: identify_gateway_firewall_targets(
                    hosts,
                    sid=sid,
                ),
                job_registry=job_registry,
                emit_job_status=emit_job_status,
                logger=logger,
                settings_state=settings_state,
                vulners_script=vulners_script,
                runtime_store=runtime_store,
            ),
        )

    def generate_report_task(sid, data):
        return generate_report_task_runtime(
            sid=sid,
            data=data,
            deps=build_report_task_deps(
                broadcaster=broadcaster,
                job_registry=job_registry,
                idle_state_manager=idle_state_manager,
                emit_job_status=emit_job_status,
                emit_to_client=emit_to_client,
                update_job_progress=update_job_progress,
                validate_target=validate_target,
                split_subnet_into_chunks=split_subnet_into_chunks,
                create_scan_folder=create_scan_folder,
                scans_dir=scans_dir,
                settings_state=settings_state,
                upload_report_artifacts_to_google_drive=upload_report_artifacts_to_google_drive,
                sanitize_customer_dir_name=sanitize_customer_dir_name,
                run_nmap_with_xml_output=run_nmap_with_xml_output,
                merge_nmap_xml_files=merge_nmap_xml_files,
                socketio_sleep=socketio.sleep,
                convert_xml_to_html=convert_xml_to_html,
                convert_html_to_pdf=convert_html_to_pdf,
                web_stylesheet=web_stylesheet,
                pdf_stylesheet=stylesheet_pdf,
                stylesheet=stylesheet,
                get_app_version=get_app_version,
                save_scan_metadata=save_scan_metadata,
                get_client_state=get_client_state,
                network_key=network_key,
                current_customer=current_customer,
                extract_scan_statistics=extract_scan_statistics,
                customer_fingerprinter=customer_fingerprinter,
                runtime_store=runtime_store,
            ),
        )

    def generate_pdf_from_saved_task(sid, data):
        return generate_pdf_from_saved_task_runtime(
            sid=sid,
            data=data,
            deps=build_saved_pdf_task_deps(
                broadcaster=broadcaster,
                job_registry=job_registry,
                emit_job_status=emit_job_status,
                emit_to_client=emit_to_client,
                get_client_state=get_client_state,
                find_latest_saved_scan_for_pdf=lambda target, **kwargs: find_latest_saved_scan_for_pdf(
                    target,
                    scans_dir=scans_dir,
                    load_json_document=load_json_document,
                    normalize_scan_metadata_document=normalize_scan_metadata_document,
                    runtime_store=runtime_store,
                    **kwargs,
                ),
                convert_xml_to_html=convert_xml_to_html,
                convert_html_to_pdf=convert_html_to_pdf,
                get_app_version=get_app_version,
                logger=logger,
                runtime_store=runtime_store,
                scans_dir=scans_dir,
                socketio_sleep=socketio.sleep,
                web_stylesheet=web_stylesheet,
                pdf_stylesheet=stylesheet_pdf,
            ),
        )

    return {
        "run_arp_scan": run_arp_scan,
        "run_nmap_with_xml_output": run_nmap_with_xml_output,
        "start_scan_task": start_scan_task,
        "generate_report_task": generate_report_task,
        "generate_pdf_from_saved_task": generate_pdf_from_saved_task,
    }
